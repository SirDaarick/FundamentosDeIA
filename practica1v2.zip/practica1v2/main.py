from scenario import Scenario

def main():
    scenario = Scenario()
    scenario.mainloop()

if __name__ == "__main__":
    main()
